# The PAIX World Fund

*A second code, for everyone else. No religion test. No membership test. No obligation.*

---

## Status

**Pre-approval.** This page describes a proposal being prepared for presentation to Holy Trinity Parish in Lenexa, Kansas, and, in due course, to the archdiocese and to Amazon Business. Nothing on this page has been blessed by a pastor, approved by a chancery, or negotiated with Amazon. It is a design, not a program.

---

## The idea in one paragraph

The **parish code** (e.g. `HTCLENEXA`) is for parishioners of Holy Trinity. When they route their ordinary Amazon spend through the caisse's link, the ~17% nonprofit procurement spread lands in their parish caisse — supporting their own neighbors, their own hardship fund, their own certified households.

The **PAIX World Fund code** is for everyone else. If you are not a Catholic, not a parishioner, not in Lenexa, not in Kansas, not in the United States — you can still route your Amazon spend through a caisse-affiliated link, and the flowback lands in a shared **PAIX World Fund** that supports network-scale infrastructure and a hardship pool any caisse can draw from.

Two codes. Same technology. You choose the destination.

---

## Why this is allowed

**There is no legal restriction on a non-Catholic supporting a Catholic parish or a Catholic-adjacent fund in the United States.** Catholic parishes and their 501(c)(3) affiliates are open to donations from any person, of any faith or no faith. The IRS does not impose a religion test on donors. The diocese does not either.

Practically:

- The parish code routes flowback into the parish's own 501(c)(3) instrument (parish bank account, parish-owned co-op, or diocesan-blessed subsidiary — the exact legal shape is a decision Father and the archdiocese make, not us).
- The World Fund code routes flowback into a separate PAIX-level entity — a religious-affiliated 501(c)(3) or non-profit co-operative — that is chartered under PAIX and governed by its own board with a Catholic-tradition governance structure.
- Neither code buys governance rights. Donating money does not buy a vote in the parish or a vote in PAIX. The Fathers' governance model — Church authority, community authority, and a public ledger — is untouched by donor identity.

---

## What the World Fund is for

The parish caisse serves parishioners. The World Fund serves the **network** that lets parish caisses exist:

1. **Ledger infrastructure.** The shared canon of the caisse ledger schema, the shop configuration format, and the build tools that any parish can fork. This costs real money to maintain (hosting, developer time, security audits) and no single parish should carry that.
2. **Network hardship pool.** When a caisse somewhere in the network takes an unexpected hit — a natural disaster, a leadership transition, a fraud loss — the World Fund can advance an interest-free bridge that the caisse repays over time. This is exactly Desjardins' original mutual-aid architecture, one level up.
3. **New-parish onboarding.** The cost of standing up a caisse (legal paperwork, ATEP enrollment, professional-provider recruitment) is real. The World Fund can carry the first-year overhead for parishes that want to start a caisse but do not yet have the surplus to bootstrap.
4. **Never for salaries at the top.** The World Fund is not a foundation for network executives. Its charter should forbid any single individual from drawing an ongoing salary greater than a parish-level median household income. This is a promise the network makes to every donor, parishioner and non-parishioner alike.

---

## Why this is not a solicitation

We are not asking anyone to donate. We are giving anyone who is *already* going to spend money on Amazon a way to route the affiliate spread — money Amazon was going to pay to someone anyway — to a fund whose books are public and whose beneficiaries are neighbors. If you like the destination, use the code. If you do not, do not use the code. Nothing changes for you either way. The buyer pays the same price. The item ships the same way. Amazon takes the same margin. Only the destination of the affiliate spread changes.

That is the entire proposition. It is a **routing choice**, not a donation solicitation.

---

## What we still do not know

Three honest caveats we want on the record:

1. **Amazon Associates commission rates are 1–10% depending on category** ([Amazon Associates rate schedule](https://affiliate-program.amazon.com/help/operating/schedule)). The higher spreads (14–22%) that appear elsewhere in this packet assume negotiated **Amazon Business** nonprofit purchasing rates, ATEP sales-tax exemption, and cooperative-purchasing contracts stacked on top. Those are not the same instrument as consumer Amazon Associates. Until the caisse actually negotiates its Amazon Business account and its OMNIA Partners cooperative membership, the World Fund's realistic flowback rate is closer to **1–10%**, not 17%.
2. **Amazon can revoke an affiliate account at any time, for any reason.** The World Fund cannot depend on Amazon for its existence. It has to be one lane of many, alongside direct giving, cooperative purchasing, and eventually locally-covenanted merchants.
3. **The World Fund entity does not exist yet.** Before a single dollar can be routed through a World Fund code, the entity has to be chartered, a board seated, a governance document adopted, and a fiscal sponsor engaged. That is months of work, not a weekend.

---

## The 3D internet, applied

The World Fund is what a **3D internet** looks like when you take it seriously: every person who buys something online gets to choose where the affiliate spread lands, and the network of possible destinations is not two (Amazon vs. a random YouTuber) but *n* — as many caisses as there are parishes, plus a shared network fund for people whose community has not started a caisse yet.

You do not have to be Catholic. You do not have to be a parishioner. You do not have to agree with PAIX's theology or governance. You just have to think that a public ledger, a Rule that fits on one line, and a network hardship fund with a salary cap are a better destination for the affiliate spread than the default.

If that is a decision worth making, use the code. If not, do not. The freedom of the 3D internet is that both answers are fine, and everyone gets to make their own routing decision, purchase by purchase.

**One good deed. One witness. One hour. One token.**

The Rule is the same in every caisse. The destination is up to you.
